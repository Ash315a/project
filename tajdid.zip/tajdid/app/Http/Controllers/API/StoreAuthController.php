<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Models\Store;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\ValidationException;

class StoreAuthController extends Controller
{
    public function register(Request $request)
    {
        $request->validate([
        'name' => 'required|string|max:255',
        'email' => 'required|string|email|unique:stores',
        'password' => 'required|string|min:8',
        'commercial_record' => 'required|image|mimes:jpeg,png,jpg|max:2048',
        ]);

        if ($request->fails()) {
            return response()->json(['errors' => $request->errors()], 422);
        }

        $recordPath = $request->file('commercial_record')->store('commercial_records', 'public');

    //if ($request->hasFile('commercial_record')) {
        //$recordPath = $request->file('commercial_record')->store('commercial_records', 'public');
    //}

        $store = Store::create([
            'name'              => $request->name,
            'email'             => $request->email,
            'password'          => bcrypt($request->password),
            'commercial_record' => $recordPath,
        ]);

        $token = $store->createToken("store-token")->plainTextToken;

        return response()->json([
            'message' => 'Store registered successfully',
            'token' => $token,
            'store' => $store
        ], 201);
    }

    public function login(Request $request)
    {
        $credentials = $request->only('email', 'password');

        $store = Store::where('email', $credentials['email'])->first();

        if (! $store || ! Hash::check($request->password, $store->password)) {
            throw ValidationException::withMessages(['email' => ['Invalid credentials']]);
        }

        return response()->json(['token' => $store->createToken("store-token")->plainTextToken]);
    }

    public function logout(Request $request)
    {
        $request->user()->currentAccessToken()->delete();
        return response()->json(['message' => 'Logged out successfully']);
    }
}
